#!/bin/bash
echo "=========================================="
echo " System Software Restorer"
echo "=========================================="

# Ensure script is run with sudo for installations
if [ "$EUID" -ne 0 ]; then
  echo "Please run the restore script with sudo: sudo ./restore.sh"
  exit 1
fi

echo "[1/4] Restoring APT repositories..."
cp -R apt-repos/* /etc/apt/sources.list.d/ 2>/dev/null || true
apt-get update

echo "[2/4] Restoring APT packages..."
if [ -s apt_packages.txt ]; then
    xargs -a apt_packages.txt apt-get install -y
fi

echo "[3/4] Restoring Snap packages..."
if [ -s snap_packages.txt ]; then
    while read -r package; do
        # Note: Some snaps require the --classic flag. The script attempts standard install first.
        snap install "$package" || snap install "$package" --classic
    done < snap_packages.txt
fi

echo "[4/4] Restoring Flatpak packages..."
if command -v flatpak >/dev/null 2>&1; then
    if [ -s flatpak_packages.txt ]; then
        flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo
        xargs -a flatpak_packages.txt -I {} flatpak install -y flathub {}
    fi
else
    echo "Flatpak is not installed on this system. Skipping Flatpak restore."
fi

echo "----------------------------------------"
echo "Restore complete! Your software has been duplicated."
